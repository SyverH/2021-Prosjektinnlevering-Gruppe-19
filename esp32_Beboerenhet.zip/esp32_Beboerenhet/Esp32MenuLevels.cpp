//***Funksjoner til bruk i hovedprogram***

#include "Esp32Utilities.h"
#include "Esp32MenuLevels.h"
#include "Esp32MenuSlidesLcd.h"

EspUtilities utilities2(true);                      //definerer objekt
EspMenuSlidesLcd slides2(true);

EspMenuLevels::EspMenuLevels(bool displayMsg) {
  // Ting for å initsiere objektet
  _msg = displayMsg;
  }

//Alle nivåer er bygd opp på samme måte:
//1. En funksjon EscSel() leser knappeinput fra enter og escape knapp
//2. Dersom enter er trykket hopper programmet inn i en if blokk og deretter rett i en while løkke.
//3. While løkka kjører så lenge ingen av utbrytervariablene blir sanne
//4. I while løkka ligger en switch case blokk.
//5. I hver case ligger enten nye nivåer bygd opp på samme måte eller en funksjon som skal kjøre. 
//6. For hver gag while løkka kjøres kalles funksjonen levelSelect()
//6. Funksjonen levelSelect() tar inn variabel om nåværende nivå og antall nivåer. Innebygd i funksjonen er knappeunput.
//7. levelSelect() inkrementerer eller dekrementerer switch case variabelen og velger dermed hvilket undernivå som kjører. (eventuellt funksjon som skal kjøres)


//*Level 1:
void EspMenuLevels::level1(){
  //****Da kollektiv!****
  slides2.level1();                                                   //skjermbilde

  enum inLevel1 {level1_1, level1_2, levelsInLevel1};                 //anngir int til et ord for å gjøre switchcase oversiktlig
  enum exit_enter1 {noInput1, exit1, enterSub1};                      //noInput = 0, exit = 1, enter = 2
  int inputExitEnter1 = 0;                                            //variabel for input fra exit og enter knappene
  int inputLevel1 = 0;                                                //variabel for input fra nivå aka pil høyre/venstre knappene
  int ExitEnter1 = 0;                                                 //variabel brukt i switchcase som bestemmer "inn i neste" eller "ut av dette" nivået
  int level1Inc = 0;                                                  //variabel som bestemmer hvilken undermeny som vises
  int temp1 = 0;                                                      //variabel brukes til å sjekke om nivå er endret

  inputExitEnter1 = utilities2.EscSel();                              //bryter A = 1, bryter B = 2, ingen bryter = 0. 
  if(inputExitEnter1 == enterSub1){
    inputExitEnter1 = noInput1; 
    slides2.lcdClear();                                                 //Klarerer skjerm etter å ha gått inn til nytt undernivå

    while(inputExitEnter1 != exit1 && !masterBreak){                    //er på dette nivået til exit knapp trykkes
      level1Inc = utilities2.levelSelect(level1Inc, levelsInLevel1);    //ender nivåvariabelen
      if (level1Inc != temp1){
        temp1 = level1Inc;
        slides2.blankLine1();                                           //sletter skjermbildet om nivået er endret //blenkLinex() fikser blinkinga
      }                      

      //**Nivåvelger**
      switch(level1Inc){                                                //nivå eller funksjons velger
        case level1_1:
          //****Sovemodus****
          EspMenuLevels::level1_1();                                   //Skjermmelding eller funksjon

        break;
        case level1_2:
          //****ledig****                                             //Skjermmelding eller funksjon
          EspMenuLevels::level1_2();

        break;
      }
      inputExitEnter1 = utilities2.EscSel();                          //Sjekker input fra enter og exit knappene
    }
    if(inputExitEnter1 == exit1){
      inputExitEnter1 = noInput1;
      slides2.lcdClear();                                             //bryter ut av undernivået om exit knapp trykkes
    }         
  }
}
//*level1_1
void EspMenuLevels::level1_1(){
  //****Dvalemodus****
  slides2.level1_1();                                                   //skjermbilde

  enum exit_enter1_1 {noInput1_1, exit1_1, enterSub1_1};                //noInput = 0, exit = 1, enter = 2
  int inputExitEnter1_1 = 0;                                            //variabel for input fra exit og enter knappene

  inputExitEnter1_1 = utilities2.EscSel();                              //bryter A = 1, bryter B = 2, ingen bryter = 0. 
  if(inputExitEnter1_1 == enterSub1_1){
    hibernateNow = true;                                                //glabal variabel vom trigger task0_deepSleep   
  }
}
//*level1_1
void EspMenuLevels::level1_2(){
  //****Instillinger****
  slides2.level1_2();                                                   //skjermbilde
}

//**Level 2:
void EspMenuLevels::level2(){
  //****Rombooking****
  slides2.level2();                                                   //skjermbilde

  enum inLevel2 {level2_1, level2_2, levelsInLevel2};                 //anngir int til et ord for å gjøre switchcase oversiktlig
  enum exit_enter2 {noInput2, exit2, enterSub2};                      //noInput = 0, exit = 1, enter = 2
  int inputExitEnter2 = 0;                                            //variabel for input fra exit og enter knappene
  int inputLevel2 = 0;                                                //variabel for input fra nivå aka pil høyre/venstre knappene
  int ExitEnter2 = 0;                                                 //variabel brukt i switchcase som bestemmer "inn i neste" eller "ut av dette" nivået
  int level2Inc = 0;                                                  //variabel som bestemmer hvilken undermeny som vises
  int temp2 = 0;                                                      //variabel brukes til å sjekke om nivå er endret

  inputExitEnter2 = utilities2.EscSel();                              //bryter A = 1, bryter B = 2, ingen bryter = 0. 
  if(inputExitEnter2 == enterSub2){
    inputExitEnter2 = noInput2; 
    slides2.lcdClear();                                                 //Klarerer skjerm etter å ha gått inn til nytt undernivå

    while(inputExitEnter2 != exit2 && !masterBreak){                    //er på dette nivået til exit knapp trykkes
      level2Inc = utilities2.levelSelect(level2Inc, levelsInLevel2);    //ender nivåvariabelen
      if (level2Inc != temp2){
        temp2 = level2Inc;
        slides2.blankLine1();                                           //sletter skjermbildet om nivået er endret //blenkLinex() fikser blinkinga
      }                      

      //**Nivåvelger**
      switch(level2Inc){                                                //nivå eller funksjons velger
        case level2_1:
          //****Bestille rom****
          EspMenuLevels::level2_1();                                   //Skjermmelding eller funksjon

        break;
        case level2_2:
          //****Avbestille rom****                                     //Skjermmelding eller funksjon
          EspMenuLevels::level2_2();

        break;
      }
      inputExitEnter2 = utilities2.EscSel();                          //Sjekker input fra enter og exit knappene
    }
    if(inputExitEnter2 == exit2){
      inputExitEnter2 = noInput2;
      slides2.lcdClear();                                             //bryter ut av undernivået om exit knapp trykkes
    }         
  }
}
//**Level 2_1:
void EspMenuLevels::level2_1(){
  //****Bestille rom****
  slides2.level2_1();                                                   //skjermbilde

  enum inLevel2_1 {level2_1_1, level2_1_2, level2_1_3, level2_1_4, levelsInLevel2_1};     //anngir int til et ord for å gjøre switchcase oversiktlig
  enum exit_enter2_1 {noInput2_1, exit2_1, enterSub2_1};                           //noInput = 0, exit = 1, enter = 2
  int inputExitEnter2_1 = 0;                                                       //variabel for input fra exit og enter knappene
  int inputLevel2_1 = 0;                                                           //variabel for input fra nivå aka pil høyre/venstre knappene
  int ExitEnter2_1 = 0;                                                            //variabel brukt i switchcase som bestemmer "inn i neste" eller "ut av dette" nivået
  int level2_1Inc = 0;                                                             //variabel som bestemmer hvilken undermeny som vises
  int temp2_1 = 0;                                                                 //variabel brukes til å sjekke om nivå er endret

  //Setter standardparameter for dette nivået 
  int bookingId = 0;                                                            //parameter for mqtt melding, tolker nå meldinga som en rombooking
  int roomBookMinimumQuantity = 1;                                              //minimumkvantitet for personbokking tili rom


  inputExitEnter2_1 = utilities2.EscSel();                                       //bryter A = 1, bryter B = 2, ingen bryter = 0
  if(inputExitEnter2_1 == enterSub2_1){
    inputExitEnter2_1 = noInput2_1; 
    slides2.blankLine2();                                                       //Klarerer skjerm etter å ha gått inn til nytt undernivå
    

    while(inputExitEnter2_1 != exit2_1 && !masterBreak){                        //er på dette nivået til exit knapp trykkes
      level2_1Inc = utilities2.levelSelect(level2_1Inc, levelsInLevel2_1);      //ender nivåvariabelen
      if (level2_1Inc != temp2_1){
        temp2_1 = level2_1Inc;
        slides2.blankLine2();                                              //sletter skjermbildet om nivået er endret
      }                      

      //**Nivåvelger**
      switch(level2_1Inc){                                               //nivå eller funksjons velger
        case level2_1_1:{
          //****Bad****
          slides2.level2_1_1();                                          //Skjermmelding eller funksjon
          int roomId = 3;                                                                       //mqtt romvelgerparameter
          utilities2.booking(bookingId, roomId, limitBathroom, roomBookMinimumQuantity);        //velger antall som skal sendes, inputvariabler er meldingsparameter
        break;}
        case level2_1_2:{
          //****Kjøkken****                                              //Skjermmelding eller funksjon
          slides2.level2_1_2();
          int roomId = 0;                                                                      //mqtt romvelgerparameter
          utilities2.booking(bookingId, roomId, limitKitchen, roomBookMinimumQuantity);        //velger antall som skal sendes, inputvariabler er meldingsparameter
        break;}
        case level2_1_3:{
          //****Stue****                                                 //Skjermmelding eller funksjon
          slides2.level2_1_3();
          int roomId = 1;                                                                       //mqtt romvelgerparameter
          utilities2.booking(bookingId, roomId, limitLivingroom, roomBookMinimumQuantity);      //velger antall som skal sendes, inputvariabler er meldingsparameter
        break;}
        case level2_1_4:{
          //****Toalett****                                                             //Skjermmelding eller funksjon
          slides2.level2_1_4();
          int roomId = 2;                                                                       //mqtt romvelgerparameter
          utilities2.booking(bookingId, roomId, limitToilet, roomBookMinimumQuantity);          //velger antall som skal sendes, inputvariabler er meldingsparameter
        break;}
      }
      inputExitEnter2_1 = utilities2.EscSel();                //Sjekker input fra enter og exit knappene
    }
    if(inputExitEnter2_1 == exit2_1){
      inputExitEnter2_1 = noInput2_1;                          //bryter ut av undernivået om exit knapp trykkes
      slides2.blankLine0();
      slides2.blankLine1();
      slides2.blankLine2();
    }         
  }
}
//**Level 2_2
void EspMenuLevels::level2_2(){
  //****Avbestille rom****
  slides2.level2_2();                                                   //skjermbilde

  enum inLevel2_2 {level2_2_1, level2_2_2, level2_2_3, level2_2_4, levelsInLevel2_2};                 //anngir int til et ord for å gjøre switchcase oversiktlig
  enum exit_enter2_2 {noInput2_2, exit2_2, enterSub2_2};                                   //noInput = 0, exit = 1, enter = 2
  int inputExitEnter2_2 = 0;                                            //variabel for input fra exit og enter knappene
  int inputLevel2_2 = 0;                                                //variabel for input fra nivå aka pil høyre/venstre knappene
  int ExitEnter2_2 = 0;                                                 //variabel brukt i switchcase som bestemmer "inn i neste" eller "ut av dette" nivået
  int level2_2Inc = 0;                                                  //variabel som bestemmer hvilken undermeny som vises
  int temp2_2 = 0;                                                      //variabel brukes til å sjekke om nivå er endret

  //Setter standardparameter for dette nivået 
  int bookingId = 1;                                                  //parameter for mqtt melding, tolker nå meldinga som en romavbooking
  int roomBookMinimumQuantity = 1;

  inputExitEnter2_2 = utilities2.EscSel();                             //bryter A = 1, bryter B = 2, ingen bryter = 0
  if(inputExitEnter2_2 == enterSub2_2){
    inputExitEnter2_2 = noInput2_2; 
    slides2.blankLine2();                                              //Klarerer skjerm etter å ha gått inn til nytt undernivå

    while(inputExitEnter2_2 != exit2_2 && !masterBreak){                                          //er på dette nivået til exit knapp trykkes
      level2_2Inc = utilities2.levelSelect(level2_2Inc, levelsInLevel2_2);         //ender nivåvariabelen
      if (level2_2Inc != temp2_2){
        temp2_2 = level2_2Inc;
        slides2.blankLine2();                                                 //sletter skjermbildet om nivået er endret
      }                     

      //**Nivåvelger**
      switch(level2_2Inc){                                                                  //nivå eller funksjons velger
        case level2_2_1:{
          //****Bad****
          slides2.level2_2_1();                                                             //Skjermmelding eller funksjon
          int roomId = 3;
          utilities2.booking(bookingId, roomId, limitBathroom, roomBookMinimumQuantity);             //velger antall som skal sendes, inputvariabler er meldingsparameter
        break;}
        case level2_2_2:{
          //****Kjøkken****                                                             //Skjermmelding eller funksjon
          slides2.level2_2_2();
          int roomId = 0;
          utilities2.booking(bookingId, roomId, limitKitchen, roomBookMinimumQuantity);               //velger antall som skal sendes, inputvariabler er meldingsparameter
        break;}
        case level2_2_3:{
          //****Stue****                                                             //Skjermmelding eller funksjon
          slides2.level2_2_3();
          int roomId = 1;
          utilities2.booking(bookingId, roomId, limitLivingroom, roomBookMinimumQuantity);          //velger antall som skal sendes, inputvariabler er meldingsparameter
        break;}
        case level2_2_4:{
          //****Toalett****                                                             //Skjermmelding eller funksjon
          slides2.level2_2_4();
          int roomId = 2;
          utilities2.booking(bookingId, roomId, limitToilet, roomBookMinimumQuantity);               //velger antall som skal sendes, inputvariabler er meldingsparameter
        break;}
      }
      inputExitEnter2_2 = utilities2.EscSel();                                       //Sjekker input fra enter og exit knappene
    }
    if(inputExitEnter2_2 == exit2_2){
      inputExitEnter2_2 = noInput2_2;                                                 //bryter ut av undernivået om exit knapp trykkes
      slides2.blankLine0();
      slides2.blankLine1();
      slides2.blankLine2();
    }         
  }
}
//***Level 3:
void EspMenuLevels::level3(){
  //****Gjestebooking****
  slides2.level3();                                                   //skjermbilde

  enum inLevel3 {level3_1, level3_2, levelsInLevel3};                 //anngir int til et ord for å gjøre switchcase oversiktlig
  enum exit_enter3 {noInput3, exit3, enterSub3};                      //noInput = 0, exit = 1, enter = 2
  int inputExitEnter3 = 0;                                            //variabel for input fra exit og enter knappene
  int inputLevel3 = 0;                                                //variabel for input fra nivå aka pil høyre/venstre knappene
  int ExitEnter3 = 0;                                                 //variabel brukt i switchcase som bestemmer "inn i neste" eller "ut av dette" nivået
  int level3Inc = 0;                                                  //variabel som bestemmer hvilken undermeny som vises
  int temp3 = 0;                                                      //variabel brukes til å sjekke om nivå er endret

  inputExitEnter3 = utilities2.EscSel();                             //bryter A = 1, bryter B = 2, ingen bryter = 0.
  if(inputExitEnter3 == enterSub3){
    inputExitEnter3 = noInput3; 
    slides2.blankLine2();                                              //Klarerer skjerm etter å ha gått inn til nytt undernivå

    while(inputExitEnter3 != exit3 && !masterBreak){                                        //er på dette nivået til exit knapp trykkes
      level3Inc = utilities2.levelSelect(level3Inc, levelsInLevel3);         //ender nivåvariabelen
      if (level3Inc != temp3){
        temp3 = level3Inc;
        slides2.blankLine2();
      }                                                                               //sletter skjermbildet om nivået er endret

      //**Nivåvelger**
      switch(level3Inc){                                                                  //nivå eller funksjons velger
        case level3_1:{
          //****Melde gjest inn****
          slides2.level3_1();                                                             //Skjermmelding eller funksjon
          int bookingId = 4;                                          //mqttparameter melde inn gjest
          int roomId = 0;
          int maxGuests = limitGuests;
          utilities2.booking(bookingId, roomId, maxGuests);          //velger antall som skal sendes, inputvariabler er meldingsparameter                         
        break;}
        case level3_2:{
          //****Melde gjest ut****                                                       //Skjermmelding eller funksjon
          slides2.level3_2();
          int bookingId = 5;                                          //mqttparameter melde ut gjest
          int roomId = 0;
          int maxGuests = limitGuests;
          utilities2.booking(bookingId, roomId, maxGuests);          //velger antall som skal sendes, inputvariabler er meldingsparameter
        break;}
      }
      inputExitEnter3 = utilities2.EscSel();                                              //Sjekker input fra enter og exit knappene
    }
    if(inputExitEnter3 == exit3){
      inputExitEnter3 = noInput3;                                                         //bryter ut av undernivået om exit knapp trykkes
      slides2.blankLine0();
      slides2.blankLine1();
      slides2.blankLine2();
    }         
  }
}
//****Level 4:
void EspMenuLevels::level4(){
  //****Status****
  slides2.level4();                                                   //skjermbilde

  enum inLevel4 {level4_1, level4_2, level4_3, levelsInLevel4};                 //anngir int til et ord for å gjøre switchcase oversiktlig
  enum exit_enter4 {noInput4, exit4, enterSub4};                      //noInput = 0, exit = 1, enter = 2
  int inputExitEnter4 = 0;                                            //variabel for input fra exit og enter knappene
  int inputLevel4 = 0;                                                //variabel for input fra nivå aka pil høyre/venstre knappene
  int ExitEnter4 = 0;                                                 //variabel brukt i switchcase som bestemmer "inn i neste" eller "ut av dette" nivået
  int level4Inc = 0;                                                  //variabel som bestemmer hvilken undermeny som vises
  int temp4 = 0;                                                      //variabel brukes til å sjekke om nivå er endret

  inputExitEnter4 = utilities2.EscSel();                             //bryter A = 1, bryter B = 2, ingen bryter = 0. 
  if(inputExitEnter4 == enterSub4){
    inputExitEnter4 = noInput4; 
    slides2.blankLine1();                                              //Klarerer skjerm etter å ha gått inn til nytt undernivå

    while(inputExitEnter4 != exit4 && !masterBreak){                                         //er på dette nivået til exit knapp trykkes
      level4Inc = utilities2.levelSelect(level4Inc, levelsInLevel4);          //ender nivåvariabelen
      if (level4Inc != temp4){
        temp4 = level4Inc;
        slides2.blankLine1();                                                 //sletter skjermbildet om nivået er endret
        slides2.blankLine2();
        if(level4Inc == level4_3){slides2.noEnter();}
      }                      

      //**Nivåvelger**
      switch(level4Inc){                                                     //nivå eller funksjons velger
        case level4_1:
          //****Temperatur****
          EspMenuLevels::level4_1();                                        //Skjermmelding eller funksjon

        break;
        case level4_2:{
          //****Ledig****                                          //Skjermmelding eller funksjon
          // 

        break;}
        case level4_3:{
          //****Wifi****                                          //Skjermmelding eller funksjon
          bool statusWifi = utilities2.checkWifi();               //sjekker wifi 
          slides2.wifiStatus(statusWifi);                           //skriver wifistatus til skjerm
        break;}
      }
      inputExitEnter4 = utilities2.EscSel();                              //Sjekker input fra enter og exit knappene
    }
    if(inputExitEnter4 == exit4){
      inputExitEnter4 = noInput4;                                         //bryter ut av undernivået om exit knapp trykkes
      slides2.blankLine0();
      slides2.blankLine1();
      slides2.blankLine2();
    }         
  }
}
//****Level 4_1: Ikke imolementert fullstendig. kun testverdier ligger inne
void EspMenuLevels::level4_1(){
  //****Romtemperatur****
  slides2.level4_1();                                                   //skjermbilde

  enum inLevel4_1 {level4_1_1, level4_1_2, level4_1_3, levelsInLevel4_1};           //anngir int til et ord for å gjøre switchcase oversiktlig
  enum exit_enter4_1 {noInput4_1, exit4_1, enterSub4_1};                //noInput = 0, exit = 1, enter = 2
  int inputExitEnter4_1 = 0;                                            //variabel for input fra exit og enter knappene
  int inputLevel4_1 = 0;                                                //variabel for input fra nivå aka pil høyre/venstre knappene
  int ExitEnter4_1 = 0;                                                 //variabel brukt i switchcase som bestemmer "inn i neste" eller "ut av dette" nivået
  int level4_1Inc = 0;                                                  //variabel som bestemmer hvilken undermeny som vises
  int temp4_1 = 0;                                                      //variabel brukes til å sjekke om nivå er endret
  
  inputExitEnter4_1 = utilities2.EscSel();                           //bryter A = 1, bryter B = 2, ingen bryter = 0. 
  if(inputExitEnter4_1 == enterSub4_1){
    inputExitEnter4_1 = noInput4_1; 
    slides2.blankLine1(); 
    slides2.blankLine2();                                          //Klarerer skjerm etter å ha gått inn til nytt undernivå
    slides2.noEnter();

    while(inputExitEnter4_1 != exit4_1 && !masterBreak){                                          //er på dette nivået til exit knapp trykkes
      level4_1Inc = utilities2.levelSelect(level4_1Inc, levelsInLevel4_1);        //Velger nivå ut i fra knappeinput
      if (level4_1Inc != temp4_1){
        temp4_1 = level4_1Inc;
        slides2.blankLine2();                                                      //sletter skjermbildet om nivået er endret      
      }                      

      //**Nivåvelger**
      switch(level4_1Inc){                                                                  //nivå eller funksjons velger
        case level4_1_1:{
          //****Gang****
          int temperatur = 15;     //Funksjon for temperatur her
          String outside = "Gang";
          slides2.showTemperature(temperatur, outside);                                                            //Skjermmelding eller funksjon

        break;}
        case level4_1_2:{
          //****Stue****                                                                 //Skjermmelding eller funksjon
          int temperatur = 22;     //Funksjon for temperatur her
          String outside = "Stue";
          slides2.showTemperature(temperatur, outside);  

        break;}
        case level4_1_3:{
          //****Ute****                                                                 //Skjermmelding eller funksjon
          int temperatur = -10;     //Funksjon for temperatur her
          String outside = "Ute";
          slides2.showTemperature(temperatur, outside);  

        break;}
      }
      inputExitEnter4_1 = utilities2.EscSel();                                              //Sjekker input fra enter og exit knappene
    }
    if(inputExitEnter4_1 == exit4_1){
      inputExitEnter4_1 = noInput4_1; 
      slides2.blankLine1(); 
      slides2.blankLine2();                                                               //bryter ut av undernivået om exit knapp trykkes
    }         
  }
}
//*****Level 5:
void EspMenuLevels::level5(){
  //****Tjenester****
  slides2.level5();                                                   //skjermbilde

  enum inlevel5 {level5_1, level5_2, level5_3, levelsInlevel5};                 //anngir int til et ord for å gjøre switchcase oversiktlig
  enum exit_enter5 {noInput5, exit5, enterSub5};                      //noInput = 0, exit = 1, enter = 2
  int inputExitEnter5 = 0;                                            //variabel for input fra exit og enter knappene
  int inputlevel5 = 0;                                                //variabel for input fra nivå aka pil høyre/venstre knappene
  int ExitEnter5 = 0;                                                 //variabel brukt i switchcase som bestemmer "inn i neste" eller "ut av dette" nivået
  int level5Inc = 0;                                                  //variabel som bestemmer hvilken undermeny som vises
  int temp5 = 0;                                                      //variabel brukes til å sjekke om nivå er endret

  inputExitEnter5 = utilities2.EscSel();                              //bryter A = 1, bryter B = 2, ingen bryter = 0. 
  if(inputExitEnter5 == enterSub5){
    inputExitEnter5 = noInput5; 
    slides2.lcdClear();                                                 //Klarerer skjerm etter å ha gått inn til nytt undernivå

    while(inputExitEnter5 != exit5 && !masterBreak){                                    //er på dette nivået til exit knapp trykkes
      level5Inc = utilities2.levelSelect(level5Inc, levelsInlevel5);         //ender nivåvariabelen
      if (level5Inc != temp5){
        temp5 = level5Inc;
        slides2.blankLine1();                                           //sletter skjermbildet om nivået er endret //blenkLinex() fikser blinkinga
      }                      

      //**Nivåvelger**
      switch(level5Inc){                                                //nivå eller funksjons velger
        case level5_1:
          //****Kjøkken****
          EspMenuLevels::level5_1();                                   //Skjermmelding eller funksjon

        break;
        case level5_2:
          //****Bad****                                     //Skjermmelding eller funksjon
          EspMenuLevels::level5_2();

        break;
        case level5_3:
          //****Stue****                                     //Skjermmelding eller funksjon
          EspMenuLevels::level5_3();

        break;
      }
      inputExitEnter5 = utilities2.EscSel();                          //Sjekker input fra enter og exit knappene
    }
    if(inputExitEnter5 == exit5){
      inputExitEnter5 = noInput5;
      slides2.lcdClear();                                             //bryter ut av undernivået om exit knapp trykkes
    }         
  }
}
//*****Level 5_1:
void EspMenuLevels::level5_1(){
  //****Tjenester Kjøkken****
  slides2.level5_1();                                                   //skjermbilde

  enum inlevel5_1 {level5_1_1, level5_1_2, level5_1_3, level5_1_4, level5_1_5, levelsInlevel5_1};                 //anngir int til et ord for å gjøre switchcase oversiktlig
  enum exit_enter5_1 {noInput5_1, exit5_1, enterSub5_1};                      //noInput = 0, exit = 1, enter = 2
  int inputExitEnter5_1 = 0;                                            //variabel for input fra exit og enter knappene
  int inputlevel5_1 = 0;                                                //variabel for input fra nivå aka pil høyre/venstre knappene
  int ExitEnter5_1 = 0;                                                 //variabel brukt i switchcase som bestemmer "inn i neste" eller "ut av dette" nivået
  int level5_1Inc = 0;                                                  //variabel som bestemmer hvilken undermeny som vises
  int temp5_1 = 0;                                                      //variabel brukes til å sjekke om nivå er endret
  
  //Setter standardparameter for dette nivået 
  int bookingId = 2;
  int roomId = 0;

  inputExitEnter5_1 = utilities2.EscSel();                              //bryter A = 1, bryter B = 2, ingen bryter = 0. 
  if(inputExitEnter5_1 == enterSub5_1){
    inputExitEnter5_1 = noInput5_1; 
    slides2.lcdClear();                                                 //Klarerer skjerm etter å ha gått inn til nytt undernivå

    while(inputExitEnter5_1 != exit5_1 && !masterBreak){                                    //er på dette nivået til exit knapp trykkes
      level5_1Inc = utilities2.levelSelect(level5_1Inc, levelsInlevel5_1);         //ender nivåvariabelen
      if (level5_1Inc != temp5_1){
        temp5_1 = level5_1Inc;
        slides2.blankLine1();                                           //sletter skjermbildet om nivået er endret //blenkLinex() fikser blinkinga
      }                      

      //**Nivåvelger**
      switch(level5_1Inc){                                                //nivå eller funksjons velger
        case level5_1_1:{
          //****Komfyr****
          int deviceID = 0;
          slides2.level5_1_1();                                          //Skjermmelding eller funksjon
          utilities2.roomBook((String)bookingId, (String)roomId, (String)deviceID);                     //caster int variabler til string og kjører funksjon for å sende melding til tjener
        break;}
        case level5_1_2:{
          //****Kaffetrakter****                                     //Skjermmelding eller funksjon
          int deviceID = 1;
          slides2.level5_1_2();
          utilities2.roomBook((String)bookingId, (String)roomId, (String)deviceID);                     //caster int variabler til string og kjører funksjon for å sende melding til tjener
        break;}
        case level5_1_3:{
          //****Oppvaskmaskin****                                     //Skjermmelding eller funksjon
          int deviceID = 2;
          slides2.level5_1_3();
          utilities2.roomBook((String)bookingId, (String)roomId, (String)deviceID);                     //caster int variabler til string og kjører funksjon for å sende melding til tjener
        break;}
        case level5_1_4:{
          //****Brødrister****                                     //Skjermmelding eller funksjon
          int deviceID = 3;
          slides2.level5_1_4();
          utilities2.roomBook((String)bookingId, (String)roomId, (String)deviceID);                     //caster int variabler til string og kjører funksjon for å sende melding til tjener
        break;}
        case level5_1_5:{
          //****Vannkoker****                                     //Skjermmelding eller funksjon
          int deviceID = 4;
          slides2.level5_1_5();
          utilities2.roomBook((String)bookingId, (String)roomId, (String)deviceID);
        break;}
      }
      inputExitEnter5_1 = utilities2.EscSel();                          //Sjekker input fra enter og exit knappene
    }
    if(inputExitEnter5_1 == exit5_1){
      inputExitEnter5_1 = noInput5_1;
      slides2.lcdClear();                                             //bryter ut av undernivået om exit knapp trykkes
    }         
  }
}
//*****Level 5_2:
void EspMenuLevels::level5_2(){
  //****Tjenester Bad****
  slides2.level5_2();                                                   //skjermbilde

  enum inlevel5_2 {level5_2_1, level5_2_2, level5_2_3, levelsInlevel5_2};                 //anngir int til et ord for å gjøre switchcase oversiktlig
  enum exit_enter5_2 {noInput5_2, exit5_2, enterSub5_2};                      //noInput = 0, exit = 1, enter = 2
  int inputExitEnter5_2 = 0;                                            //variabel for input fra exit og enter knappene
  int inputlevel5_2 = 0;                                                //variabel for input fra nivå aka pil høyre/venstre knappene
  int ExitEnter5_2 = 0;                                                 //variabel brukt i switchcase som bestemmer "inn i neste" eller "ut av dette" nivået
  int level5_2Inc = 0;                                                  //variabel som bestemmer hvilken undermeny som vises
  int temp5_2 = 0;                                                      //variabel brukes til å sjekke om nivå er endret

  //Setter standardparameter for dette nivået 
  int bookingId = 2;
  int roomId = 3;

  inputExitEnter5_2 = utilities2.EscSel();                              //bryter A = 1, bryter B = 2, ingen bryter = 0. 
  if(inputExitEnter5_2 == enterSub5_2){
    inputExitEnter5_2 = noInput5_2; 
    slides2.lcdClear();                                                 //Klarerer skjerm etter å ha gått inn til nytt undernivå

    while(inputExitEnter5_2 != exit5_2 && !masterBreak){                                    //er på dette nivået til exit knapp trykkes
      level5_2Inc = utilities2.levelSelect(level5_2Inc, levelsInlevel5_2);         //ender nivåvariabelen
      if (level5_2Inc != temp5_2){
        temp5_2 = level5_2Inc;
        slides2.blankLine1();                                           //sletter skjermbildet om nivået er endret //blenkLinex() fikser blinkinga
      }                      

      //**Nivåvelger**
      switch(level5_2Inc){                                                //nivå eller funksjons velger
        case level5_2_1:{
          //****Vaskemaskin****
          int deviceID = 0;
          slides2.level5_2_1();                                          //Skjermmelding eller funksjon
          utilities2.roomBook((String)bookingId, (String)roomId, (String)deviceID);                     //caster int variabler til string og kjører funksjon for å sende melding til tjener
        break;}
        case level5_2_2:{
          //****Tørketrommel****                                     //Skjermmelding eller funksjon
          int deviceID = 1;
          slides2.level5_2_2();
          utilities2.roomBook((String)bookingId, (String)roomId, (String)deviceID);                     //caster int variabler til string og kjører funksjon for å sende melding til tjener
        break;}
        case level5_2_3:{
          //****hårtærker****                                     //Skjermmelding eller funksjon
          int deviceID = 2;
          slides2.level5_2_3();
          utilities2.roomBook((String)bookingId, (String)roomId, (String)deviceID);                     //caster int variabler til string og kjører funksjon for å sende melding til tjener
        break;}
      }
      inputExitEnter5_2 = utilities2.EscSel();                          //Sjekker input fra enter og exit knappene
    }
    if(inputExitEnter5_2 == exit5_2){
      inputExitEnter5_2 = noInput5_2;
      slides2.lcdClear();                                             //bryter ut av undernivået om exit knapp trykkes
    }         
  }
}
//*****Level 5_3:
void EspMenuLevels::level5_3(){
  //****Tjenester Stue****
  slides2.level5_3();                                                   //skjermbilde

  enum inlevel5_3 {level5_3_1, level5_3_2, levelsInlevel5_3};                 //anngir int til et ord for å gjøre switchcase oversiktlig
  enum exit_enter5_3 {noInput5_3, exit5_3, enterSub5_3};                      //noInput = 0, exit = 1, enter = 2
  int inputExitEnter5_3 = 0;                                            //variabel for input fra exit og enter knappene
  int inputlevel5_3 = 0;                                                //variabel for input fra nivå aka pil høyre/venstre knappene
  int ExitEnter5_3 = 0;                                                 //variabel brukt i switchcase som bestemmer "inn i neste" eller "ut av dette" nivået
  int level5_3Inc = 0;                                                  //variabel som bestemmer hvilken undermeny som vises
  int temp5_3 = 0;                                                      //variabel brukes til å sjekke om nivå er endret

  //Setter standardparameter for dette nivået 
  int bookingId = 2;
  int roomId = 3;

  inputExitEnter5_3 = utilities2.EscSel();                              //bryter A = 1, bryter B = 2, ingen bryter = 0. 
  if(inputExitEnter5_3 == enterSub5_3){
    inputExitEnter5_3 = noInput5_3; 
    slides2.lcdClear();                                                 //Klarerer skjerm etter å ha gått inn til nytt undernivå

    while(inputExitEnter5_3 != exit5_3 && !masterBreak){                                    //er på dette nivået til exit knapp trykkes
      level5_3Inc = utilities2.levelSelect(level5_3Inc, levelsInlevel5_3);         //ender nivåvariabelen
      if (level5_3Inc != temp5_3){
        temp5_3 = level5_3Inc;
        slides2.blankLine1();                                           //sletter skjermbildet om nivået er endret //blenkLinex() fikser blinkinga
      }                      

      //**Nivåvelger**
      switch(level5_3Inc){                                                //nivå eller funksjons velger
        case level5_3_1:{
          //****TV****
          int deviceID = 0;
          slides2.level5_3_1();                                          //Skjermmelding eller funksjon
          utilities2.roomBook((String)bookingId, (String)roomId, (String)deviceID);                     //caster int variabler til string og kjører funksjon for å sende melding til tjener
        break;}
        case level5_3_2:{
          //****Stereoanlegg****                                     //Skjermmelding eller funksjon
          int deviceID = 1;
          slides2.level5_3_2();
          utilities2.roomBook((String)bookingId, (String)roomId, (String)deviceID);                     //caster int variabler til string og kjører funksjon for å sende melding til tjener
        break;}
      }
      inputExitEnter5_3 = utilities2.EscSel();                          //Sjekker input fra enter og exit knappene
    }
    if(inputExitEnter5_3 == exit5_3){
      inputExitEnter5_3 = noInput5_3;
      slides2.lcdClear();                                             //bryter ut av undernivået om exit knapp trykkes
    }     
  }
}
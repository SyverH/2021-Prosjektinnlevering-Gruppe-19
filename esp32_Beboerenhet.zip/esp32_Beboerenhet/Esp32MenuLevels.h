//***Funksjoner til bruk i hovedprogram***

#ifndef Esp32_MenuLevels   //Sjekker om headerfila er kjørt. Alternativt #pragma once
#define Esp32_MenuLevels   //Er den ikke kjørt blir fila kjørt, hvis ikke hopper koden til #endif

//Sjekker hvilken arduinoversjon som brukes og legger til riktig arduino headaer.
#if (ARDUINO >=100)    
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif

//Grenseverdier antall personer per rom
extern const int limitGuests;
extern const int limitKitchen;
extern const int limitLivingroom;
extern const int limitToilet;
extern const int limitBathroom;

//variabler som kan bryte ut av menyene
extern int hibernateNow;
extern bool masterBreak;

class EspMenuLevels  {
  public:
    // Constructor 
    EspMenuLevels(bool displayMsg=false);

    //Nivåfunksjoner
    //***Level 1****  
    void level1();      //Hjemskjerm
    void level1_1();    //Dvalemodus
    void level1_2();    //Ingenting

    //***Level 2****
    void level2();      //Rombooking
    void level2_1();    //Bestille rom
    void level2_2();    //Avbestille rom
    

    //***Level 3****
    void level3();      //Gjestebooking

    //***Level 4****
    void level4();      //Statuser
    void level4_1();    //Romtemperatur **ikke implementert
    void level4_2();    //Utetemperatur **ikke implementert

    //***Level 5***
    void level5();      //Tjenester
    void level5_1();    //Kjøkken
    void level5_2();    //Bad
    void level5_3();    //Stue
    

  private:
    bool _msg;
};
#endif

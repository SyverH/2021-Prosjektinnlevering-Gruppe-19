//***Kommunikasjon med LCDdisplay over I2C***
//***Alle menyskjermer***

#include "Esp32Utilities.h"
#include "Esp32MenuSlidesLcd.h"                 //inkluderer header fil
#include <LiquidCrystal_I2C.h>  //Biblotek for å bruke lcd display. *Bruker arduinos wire.h for I2C-kommunikasjon til lcd skjerm

//Skjermparameter for displayet hentes fra .ino fila i .h fila og implementeres her når objektet defineres
LiquidCrystal_I2C lcd(lcdAdress,lcdColumns,lcdRows);            

EspMenuSlidesLcd::EspMenuSlidesLcd(bool displayMsg) {
  // Ting for å initsiere objektet
  _msg = displayMsg;
  }
// Skjermfunksjoner  og skjermsletting:
//Starter skjerm. Plasseres i setup
void EspMenuSlidesLcd::lcdInitialize(){
  lcd.init();                                   //initialize the lcd 
  lcd.backlight();                              //skrur på bakgrunnslyset
  lcd.clear();                                  //nullstiller skjermen
  }
  //Skrur av skjermen
  void EspMenuSlidesLcd::off(){
    lcd.noBacklight();                            //Skrur av bakgrunnslys
    lcd.clear();                                  //nullstiller skjermen
  }
  //Skrur på bakgrunnslyset
  void EspMenuSlidesLcd::on(){
    lcd.backlight();                              //skrur på bakgrunnslyset
  }
  //sletter skjermbildet
  void EspMenuSlidesLcd::lcdClear(){
    lcd.clear();                                  //Nulstiller skjermen. Må gjøres før nytt bilde skrives til skjerm **når jeg kjører lcd.clear (i andre cpp filer (da med nytt objekt ekempel lcd2.clear())) blinker skjermen, men kjører jeg EspMenuSlidesLcd::lcdClear() blinker skjermen ikke. rart
  }
  void EspMenuSlidesLcd::clearPopUp(){
    lcd.setCursor(2,0); lcd.print("              ");
  }
  void EspMenuSlidesLcd::blankLine0(){
    lcd.setCursor(0,0); lcd.print("                    ");
  }
  void EspMenuSlidesLcd::blankLine1(){
    lcd.setCursor(0,1); lcd.print("                    ");
  }
  void EspMenuSlidesLcd::blankLine2(){
    lcd.setCursor(0,2); lcd.print("                    ");
  }
  void EspMenuSlidesLcd::blankLine3(){
    lcd.setCursor(0,3); lcd.print("                    ");
  }
  void EspMenuSlidesLcd::blankLine3s(){
    lcd.setCursor(4,3); lcd.print("          ");
  }
  void EspMenuSlidesLcd::blankScreen(){
    lcd.setCursor(0,0); lcd.print("                    ");
    lcd.setCursor(0,1); lcd.print("                    ");
    lcd.setCursor(0,2); lcd.print("                    ");
    lcd.setCursor(0,3); lcd.print("                    ");
  }
  void EspMenuSlidesLcd::arrowsOnly(){
    lcd.setCursor(0,3); lcd.print("<-");          //pil venstre
    lcd.setCursor(18,3); lcd.print("->");         //pil høyre
  }
  void EspMenuSlidesLcd::arrowsAndEnter(){
    lcd.setCursor(0,3); lcd.print("<-");          //pil venstre
    lcd.setCursor(18,3); lcd.print("->");         //pil høyre
    lcd.setCursor(6,3); lcd.print("   >>   ");          //enter
  }
  void EspMenuSlidesLcd::arrowsAndEsc(){
    lcd.setCursor(0,3); lcd.print("<-");          //pil venstre
    lcd.setCursor(18,3); lcd.print("->");         //pil høyre
    lcd.setCursor(0,0); lcd.print("esc");         //escape
  }
  void EspMenuSlidesLcd::arrowsEscEnter(){
    lcd.setCursor(0,3); lcd.print("<-");          //pil venstre
    lcd.setCursor(18,3); lcd.print("->");         //pil høyre
    lcd.setCursor(0,0); lcd.print("esc");         //escape
    lcd.setCursor(6,3); lcd.print("   >>   ");          //enter
  }
  void EspMenuSlidesLcd::noEnter(){
    lcd.setCursor(6,3); lcd.print("        ");          //enter
  }
//Skjermmeldinger
void EspMenuSlidesLcd::incrementAndSend(int levelXInc, int limitMax){
  lcd.setCursor(7,1); lcd.print("Antall:");
  lcd.setCursor(9,2); lcd.print(levelXInc);
                                                //**Knapper**
  if (limitMax != 1){
  lcd.setCursor(0,3); lcd.print("-1");          //pil venstre**legges til kun om det er tillat med flere enn 1
  lcd.setCursor(18,3); lcd.print("+1");         //pil høyre
  }
  lcd.setCursor(8,3); lcd.print("Send");          //enter
  lcd.setCursor(0,0); lcd.print("esc");         //escape
  }
  void EspMenuSlidesLcd::sending(){
    lcd.setCursor(3,1); lcd.print("Kontakter server");
    lcd.setCursor(4,2); lcd.print("Venligst vent");
  }
  void EspMenuSlidesLcd::waiting(){
    lcd.setCursor(3,1); lcd.print("Venter pa svar");
    lcd.setCursor(4,2); lcd.print("Venligst vent");
  }
  void EspMenuSlidesLcd::serverTimeout(){
    lcd.setCursor(3,1); lcd.print("Server timeout");
    lcd.setCursor(4,2); lcd.print("Prov igjen!");
  }
  void EspMenuSlidesLcd::orderApproved(){
    lcd.setCursor(5,1); lcd.print("Godkjent");
  }
  void EspMenuSlidesLcd::orderDisapproved(){
    lcd.setCursor(2,1); lcd.print("Ikke godkjent");
  }
  void EspMenuSlidesLcd::wifiFailed(){
    lcd.setCursor(4,1); lcd.print("Ingen Wifi");
    lcd.setCursor(3,2); lcd.print("Restart enhet");
  }
  void EspMenuSlidesLcd::wifiNo(){
    lcd.setCursor(4,0); lcd.print("No wifi");
  }
  void EspMenuSlidesLcd::wifiConnected(){
    lcd.setCursor(4,0); lcd.print("Wifi OK");
  }
  void EspMenuSlidesLcd::mqttFailed(){
    lcd.setCursor(3,0); lcd.print("Serverfeil");
  }
  void EspMenuSlidesLcd::mqttConnected(){
    lcd.setCursor(4,0); lcd.print("Server OK");
  }
  void EspMenuSlidesLcd::showTemperature(int temperatur, String location){
    lcd.setCursor(5,1); lcd.print("Temperatur");
    lcd.setCursor(3,2); lcd.print(location);
    if(9<temperatur && temperatur<100){
      lcd.setCursor(12,2); lcd.print(temperatur);
      lcd.setCursor(14,2); lcd.print("C");
    }
    else if(-1<temperatur && temperatur<10){
      lcd.setCursor(12,2); lcd.print(temperatur);
      lcd.setCursor(13,2); lcd.print("C ");
    }
    else if(-10<temperatur && temperatur<0){
      lcd.setCursor(11,2); lcd.print(temperatur);
      lcd.setCursor(13,2); lcd.print("C ");
    }
    else if(-100<temperatur && temperatur<-9){
      lcd.setCursor(11,2); lcd.print(temperatur);
      lcd.setCursor(14,2); lcd.print("C");
    }
    else{
      lcd.setCursor(4,2); lcd.print("Out Of Range");
    }
    //**Knapper**
    EspMenuSlidesLcd::arrowsAndEsc();
  }
//wifistatusprint
void EspMenuSlidesLcd::wifiStatus(bool statusWifi){
    lcd.setCursor(8,1); lcd.print("Wifi");
    if(statusWifi){
      lcd.setCursor(3,2); lcd.print("      OK      ");
    }
    else{
      lcd.setCursor(3,2); lcd.print("ikke tilkoblet");
    }
    //**Knapper**
    EspMenuSlidesLcd::arrowsAndEsc();
  }
//Skjermbilder per level
//*Level 1
void EspMenuSlidesLcd::level1(){
  lcd.setCursor(8,1); lcd.print("Da"); 
  lcd.setCursor(5,2); lcd.print("Kollektiv!");
  //**Knapper**
  EspMenuSlidesLcd::arrowsOnly();
  }
  //*
  void EspMenuSlidesLcd::level1_1(){
    lcd.setCursor(5,1); lcd.print("Dvalemodus");
    //**Knapper**
    lcd.setCursor(7,3); lcd.print("Dvale");          
    EspMenuSlidesLcd::arrowsAndEsc();
  }
  //*
  void EspMenuSlidesLcd::level1_2(){
    lcd.setCursor(4,1); lcd.print("Instillinger");
    //**Knapper**
    EspMenuSlidesLcd::arrowsAndEsc();
    EspMenuSlidesLcd::noEnter();
  }
//**Level 2
void EspMenuSlidesLcd::level2(){
  lcd.setCursor(5,1); lcd.print("Rombooking");
  //**Knapper**
  EspMenuSlidesLcd::arrowsAndEnter();
  }
  //**
  void EspMenuSlidesLcd::level2_1(){
    lcd.setCursor(6,1); lcd.print("Bestille");
    lcd.setCursor(8,2); lcd.print("Rom");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }
  //**
  void EspMenuSlidesLcd::level2_1_1(){
    lcd.setCursor(6,1); lcd.print("Bestille");
    lcd.setCursor(8,2); lcd.print("Bad");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }
  //**
  void EspMenuSlidesLcd::level2_1_2(){
    lcd.setCursor(6,1); lcd.print("Bestille");
    lcd.setCursor(6,2); lcd.print("Kjokken");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }
  //**
  void EspMenuSlidesLcd::level2_1_3(){
    lcd.setCursor(6,1); lcd.print("Bestille");
    lcd.setCursor(7,2); lcd.print("Stue");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }
  //**
  void EspMenuSlidesLcd::level2_1_4(){
    lcd.setCursor(6,1); lcd.print("Bestille");
    lcd.setCursor(6,2); lcd.print("Toalett");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }
  //**
  void EspMenuSlidesLcd::level2_2(){
    lcd.setCursor(5,1); lcd.print("Avbestille");
    lcd.setCursor(8,2); lcd.print("Rom");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }
  //**
  void EspMenuSlidesLcd::level2_2_1(){
    lcd.setCursor(5,1); lcd.print("Avbestille");
    lcd.setCursor(8,2); lcd.print("Bad");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }
  //**
  void EspMenuSlidesLcd::level2_2_2(){
    lcd.setCursor(5,1); lcd.print("Avbestille");
    lcd.setCursor(6,2); lcd.print("Kjokken");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }
  //**
  void EspMenuSlidesLcd::level2_2_3(){
    lcd.setCursor(5,1); lcd.print("Avbestille");
    lcd.setCursor(7,2); lcd.print("Stue");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }
  //**
  void EspMenuSlidesLcd::level2_2_4(){
    lcd.setCursor(5,1); lcd.print("Avbestille");
    lcd.setCursor(6,2); lcd.print("Toalett");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }
//***Level 3
void EspMenuSlidesLcd::level3(){
  lcd.setCursor(4,1); lcd.print("Gjestebooking");
  //**Knapper**     
  EspMenuSlidesLcd::arrowsAndEnter();
  }
  //***
  void EspMenuSlidesLcd::level3_1(){
    lcd.setCursor(2,1); lcd.print("Melde min gjest");
    lcd.setCursor(8,2); lcd.print("Inn");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }
  //***
  void EspMenuSlidesLcd::level3_2(){
    lcd.setCursor(2,1); lcd.print("Melde min gjest");
    lcd.setCursor(8,2); lcd.print("Ut");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }

//****Level 4
void EspMenuSlidesLcd::level4(){
  lcd.setCursor(7,1); lcd.print("Status");
  //**Knapper**
  EspMenuSlidesLcd::arrowsAndEnter();
  }
  //****
  void EspMenuSlidesLcd::level4_1(){
    lcd.setCursor(5,1); lcd.print("Temperatur");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }
  //****
  void EspMenuSlidesLcd::level4_1_1(){
    lcd.setCursor(7,1); lcd.print("Gang");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }
  //****
  void EspMenuSlidesLcd::level4_1_2(){
    lcd.setCursor(7,1); lcd.print("Stue");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }
  //****
  void EspMenuSlidesLcd::level4_2(){

    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
  }

//*****Level 5
void EspMenuSlidesLcd::level5(){
  lcd.setCursor(6,1); lcd.print("Tjenester");
  //**Knapper**
  EspMenuSlidesLcd::arrowsAndEnter();
  }
  //*****
  void EspMenuSlidesLcd::level5_1(){
    lcd.setCursor(6,1); lcd.print("Kjokken");
    //**Knapper*
    EspMenuSlidesLcd::arrowsEscEnter();
    }
    //*****
    void EspMenuSlidesLcd::level5_1_1(){
      lcd.setCursor(6,1); lcd.print("Komfyr");
      //**Knapper**
      EspMenuSlidesLcd::arrowsEscEnter();
    }
    //*****
    void EspMenuSlidesLcd::level5_1_2(){
      lcd.setCursor(4,1); lcd.print("Kaffetrakter");
      //**Knapper**
      EspMenuSlidesLcd::arrowsEscEnter();
    }
    //*****
    void EspMenuSlidesLcd::level5_1_3(){
      lcd.setCursor(4,1); lcd.print("Oppvaskmaskin");
      //**Knapper**
      EspMenuSlidesLcd::arrowsEscEnter();
    }
    //*****
    void EspMenuSlidesLcd::level5_1_4(){
      lcd.setCursor(6,1); lcd.print("Brodrister");
      //**Knapper**
      EspMenuSlidesLcd::arrowsEscEnter();
    }
    //*****
    void EspMenuSlidesLcd::level5_1_5(){
      lcd.setCursor(6,1); lcd.print("Vannkoker");
      //**Knapper**
      EspMenuSlidesLcd::arrowsEscEnter();
    }
  //*****
  void EspMenuSlidesLcd::level5_2(){
    lcd.setCursor(8,1); lcd.print("Bad");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
    }
    //*****
    void EspMenuSlidesLcd::level5_2_1(){
      lcd.setCursor(4,1); lcd.print("Vaskemaskin");
      //**Knapper**
      EspMenuSlidesLcd::arrowsEscEnter();
    }
    //*****
    void EspMenuSlidesLcd::level5_2_2(){
      lcd.setCursor(4,1); lcd.print("Torketrommel");
      //**Knapper**
      EspMenuSlidesLcd::arrowsEscEnter();
    }
    //*****
    void EspMenuSlidesLcd::level5_2_3(){
      lcd.setCursor(6,1); lcd.print("Hartorker");
      //**Knapper**
      EspMenuSlidesLcd::arrowsEscEnter();
    }
  //*****
  void EspMenuSlidesLcd::level5_3(){
    lcd.setCursor(8,1); lcd.print("Stue");
    //**Knapper**
    EspMenuSlidesLcd::arrowsEscEnter();
    }
    //*****
    void EspMenuSlidesLcd::level5_3_1(){
      lcd.setCursor(9,1); lcd.print("TV");
      //**Knapper**
      EspMenuSlidesLcd::arrowsEscEnter();
    }
    //*****
    void EspMenuSlidesLcd::level5_3_2(){
      lcd.setCursor(4,1); lcd.print("Stereoanlegg");
      //**Knapper**
      EspMenuSlidesLcd::arrowsEscEnter();
    }








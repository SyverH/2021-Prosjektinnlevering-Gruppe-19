//***Kommunikasjon med LCDdisplay over I2C***
//***Alle menyskjermer***

#ifndef Esp32_Menu_Slides_Lcd   //Sjekker om headerfila er kjørt. Alternativt #pragma once
#define Esp32_Menu_Slides_Lcd   //Er den ikke kjørt blir fila kjørt, hvis ikke hopper koden til nederste#endif

//Sjekker hvilken arduinoversjon som brukes og legger til riktig arduino headaer.
#if (ARDUINO >=100)    
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif

//Lcd skjermparameter
extern const uint8_t lcdAdress;       // lcdadresse fra .ino fila
extern const uint8_t lcdColumns;      // antall kolonner fra .ino fila
extern const uint8_t lcdRows;         // antall rader fra .ino fila

class EspMenuSlidesLcd  {
  public:
    // Constructor 
    EspMenuSlidesLcd(bool displayMsg=false);

    // Skjermfunksjoner  og skjermsletting:
    //Initsialiserer lcd skjerm. kjøres ved opstart
    void lcdInitialize();
    //Skrur av skjermen
    void off();
    //Skrur på bakgrunnslyset
    void on();
    //Sletter skjermbildet
    void lcdClear();
    //Skriver blanke felter på midterste del av linje 0
    void clearPopUp();
    //Skriver blanke linjer
    void blankLine0();
    void blankLine1();
    void blankLine2();
    void blankLine3();
    //Skriver blanke felter på midterste del av linje 3
    void blankLine3s();
    //Skriver blanke felter på hele skjermen
    void blankScreen();
    //Skriver kun piler
    void arrowsOnly();
    //Skriver piler og enterknapp
    void arrowsAndEnter();
    //Skriver piler og esc
    void arrowsAndEsc();
    //Skriver piler escape og enterknapp
    void arrowsEscEnter();
    //Samme som blankline3s
    void noEnter();

    // Skjermmeldinger:
    //Skriver variabelen levelXInc til skjerm
    void incrementAndSend(int levelXInc, int limitMax);
    //"kontatkter server" melding
    void sending();
    //"venter på server"
    void waiting();
    //"Server svarte ikke" melding
    void serverTimeout();
    //"Forespørsel godkjent" melding
    void orderApproved();
    //"Forespørsel ikke godkjent" melding
    void orderDisapproved();
    //"wifitilkobling feilet" melding
    void wifiFailed();
    //"wifi ikke tilkoblet" melding
    void wifiNo();
    //"wifi tilkoblet" melding
    void wifiConnected();
    //"Serverfeil" melding
    void mqttFailed();
    //"Server ok" melding
    void mqttConnected();
    //"wifistatus" melding
    void wifiStatus(bool statusWifi);    //Wifistatus    
    void showTemperature(int temperatur, String location = "");    //Utetemperatur **ikke implementert, kun eksempelverdier vises

    //***Level 1****    //Skjermbilder:
    void level1();      //Hjemskjerm
    void level1_1();    //Dvalemodus
    void level1_2();    //Ingenting

    //***Level 2****
    void level2();      //Rombooking
    void level2_1();    //Bestille rom
    void level2_1_1();  //*Bad
    void level2_1_2();  //*Kjøkken
    void level2_1_3();  //*Stue
    void level2_1_4();  //*Toalett
    void level2_2();    //Avbestille rom
    void level2_2_1();  //*Bad
    void level2_2_2();  //*Kjøkken
    void level2_2_3();  //*Stue
    void level2_2_4();  //*Toalett
    

    //***Level 3****
    void level3();      //Gjestebooking
    void level3_1();    //Melde gjest INN
    void level3_2();    //Melde gjest UT

    //***Level 4****
    void level4();      //Statuser
    void level4_1();    //Romtemperatur **ikke implementert
    void level4_1_1();  //Gang          **ikke implementert
    void level4_1_2();  //Stue          **ikke implementert
    void level4_2();  //              **ikke implementert

    //***Level 5***
    void level5();      //Tjenester
    void level5_1();    //Kjøkken
    void level5_1_1();  //*Komfyr
    void level5_1_2();  //*Kaffetrakter
    void level5_1_3();  //*Oppvaskmaskin
    void level5_1_4();  //*Brødrister
    void level5_1_5();  //*Vannkoker
    void level5_2();    //Bad
    void level5_2_1();  //*Vaskemaskin
    void level5_2_2();  //*Tørketrommel
    void level5_2_3();  //*Hårtørker
    void level5_3();    //Stue
    void level5_3_1();  //*TV
    void level5_3_2();  //*Stereoanlegg
    
    


  private:
    bool _msg;
};
#endif

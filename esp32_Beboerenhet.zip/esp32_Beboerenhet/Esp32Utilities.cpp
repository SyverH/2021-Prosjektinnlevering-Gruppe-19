//***Funksjoner til bruk i hovedprogram***

#include "Esp32Utilities.h"
#include "Esp32MenuSlidesLcd.h"
#include <PubSubClient.h> // Connect and publish to the MQTT broker
#include <WiFi.h> // Enables the ESP32 to connect to the local network (via WiFi)

//Definerer objekt av bibliotekklassene.
WiFiClient wifiClient;                                            // Initialise the WiFi and MQTT Client objects
PubSubClient client(mqtt_server, 1883, wifiClient);               // 1883 is the listener port for the Broker
EspMenuSlidesLcd slides3(true);                                   //

//Global variabel brukes av callbackfunksjonen for å skru av skjermmeldinga når en tid har passert
bool breakoutOfmqttMessage = false;

//Definerer konstruktør.
EspUtilities::EspUtilities(bool displayMsg) {
  // Ting for å initsiere objektet
  _msg = displayMsg;
  }

//Callbackfunksjon gir godkjent eller ikke godkjent skjermmelding når callback flagg blir satt av mqtt tjener.
//Ville ikke funngere når den var en del av klassen. Er derfor ikke deklarert i klassen EspUtilities
void callback(const char* mqtt_Recieve_topic, uint8_t* payload, unsigned int length){
  //array for å motta data streng fra mqtt
  String recieved_data[8]; 

  Serial.print("Message arrived [");
  Serial.print(mqtt_Recieve_topic);
  Serial.println("] ");

  //Itererer igjennom datastrengen mottatt. 
  //Dersom parameter stemmer blir skjermmelding vist
  for (int i = 0; i < length; i++) {
    recieved_data[i] = (char)payload[i];
    if(recieved_data[i] == "1" ){
      slides3.lcdClear();                     //skjermklarering
      slides3.orderApproved();                //skjermmelding godkjent bestilling
      vTaskDelay(pdMS_TO_TICKS(responseMessageTime));
      breakoutOfmqttMessage = true;           //Global variabel brukes av callbackfunksjonen for å skru av skjermmeldinga når en tid har passert
      Serial.println("The room was booked");
    }
    else if (recieved_data[i] == "2"){
      slides3.lcdClear();                     //skjermklarering
      slides3.orderDisapproved();             //skjermmelding ikke godkjent bestilling
      vTaskDelay(pdMS_TO_TICKS(responseMessageTime));
      breakoutOfmqttMessage = true;           //Global variabel brukes av callbackfunksjonen for å skru av skjermmeldinga når en tid har passert
      Serial.println("The room is unavailable");
    }
  }
  Serial.print(recieved_data[1]);
  Serial.println();
} 

// Funksjon for å starte seriell kommuikasjon
void EspUtilities::begin(int baudRate) {
  Serial.setTimeout(50);
  Serial.begin(baudRate);
  if (_msg) {
    Serial.println("Utilities lib constructor initiert.");
    }
  }

//inkrementerer 1 opp eller ned fra level. returnerer int mellom 0 og variabel levels. Input fra to brytere. Pulldown eller pullup angis til slutt
int EspUtilities::levelSelect(int level, const int levels, const int minLevel, const uint8_t pinButtonA, const uint8_t pinButtonB, const bool pulldown, const int buttonDelay){
  int input = 0;
  bool buttonA = digitalRead(pinButtonA);
  bool buttonB = digitalRead(pinButtonB);
  
  switch(pulldown){
    //dersom pulldown resistor brukes
    case true:
      if (buttonA == HIGH){
        //Setter input variabel
        input = 1;
        //Stopper programmet for å gi bruker tid til å slippe knappen. Stopper ikke de andre taskene
        vTaskDelay(pdMS_TO_TICKS(buttonDelay));
        
      }
      else if (buttonB == HIGH){
        //Setter input variabel
        input = 2;
        //Stopper programmet for å gi bruker tid til å slippe knappen. Stopper ikke de andre taskene
        vTaskDelay(pdMS_TO_TICKS(buttonDelay));
        
      }
      else {input = 0;}
    break;
    //dersom pullup resistor brukes
    case false:
      if (buttonA == LOW){
        //Setter input variabel
        input = 1;
        //Stopper programmet for å gi bruker tid til å slippe knappen. Stopper ikke de andre taskene
        vTaskDelay(pdMS_TO_TICKS(buttonDelay));
        
      }
      else if (buttonB == LOW){
        //Setter input variabel
        input = 2;
        //Stopper programmet for å gi bruker tid til å slippe knappen. Stopper ikke de andre taskene
        vTaskDelay(pdMS_TO_TICKS(buttonDelay));
        
      }
      else {input = 0;}
    break;
  }
    switch (input){
      case 1:
      //back
        level -= 1;
        if (level < minLevel){level = levels-1;}
      break;
      case 2:
      //enter
        level += 1;
        if (level == levels){level = minLevel;}
      break;
    }
  return level;
}
//Mapper to knapper til int 1 og int 2. int 0 ved ingen knapp trykket. Pulldownbrytere -> pulldown=true Pullupbrytere -> pullup=false.
int EspUtilities::EscSel(const int pinButtonA, const int pinButtonB, const bool pulldown, const int buttonDelay){
  int input = 0;
  //Leser knappene hver gang funksjonen kalles
  bool buttonA = digitalRead(pinButtonA);
  bool buttonB = digitalRead(pinButtonB);
  
  switch(pulldown){
    //dersom pulldown resistor brukes
    case true:
      if (buttonA == HIGH){
        //Setter input variabel
        input = 1;
        //Stopper programmet for å gi bruker tid til å slippe knappen. Stopper ikke de andre taskene
        vTaskDelay(pdMS_TO_TICKS(buttonDelay));
      }
      else if (buttonB == HIGH){
        //Setter input variabel
        input = 2;
        //Stopper programmet for å gi bruker tid til å slippe knappen. Stopper ikke de andre taskene
        vTaskDelay(pdMS_TO_TICKS(buttonDelay));
      }
      else {input = 0;}
    break;
    //dersom pullup resistor brukes
    case false:
      if (buttonA == LOW){
        //Setter input variabel
        input = 1;
        //Stopper programmet for å gi bruker tid til å slippe knappen. Stopper ikke de andre taskene
        vTaskDelay(pdMS_TO_TICKS(buttonDelay));
      }
      else if (buttonB == LOW){
        //Setter input variabel
        input = 2;
        //Stopper programmet for å gi bruker tid til å slippe knappen. Stopper ikke de andre taskene
        vTaskDelay(pdMS_TO_TICKS(buttonDelay));
      }
      //Dersom ingen input så er input 0
      else {input = 0;}
    break;
  }
  //Returnerer input
  return input;
}
//Samme som EscSel. Det var oversiklig å ha to navn som tilsvarer knappene
int EspUtilities::buttonsMinusPlus(const int pinButtonA, const int pinButtonB, const bool pulldown, const int buttonDelay){
  int input = 0;
  bool buttonA = digitalRead(pinButtonA);
  bool buttonB = digitalRead(pinButtonB);
  
  switch(pulldown){
    case true:
      if (buttonA == HIGH){
        input = 1;
        vTaskDelay(pdMS_TO_TICKS(buttonDelay));
      }
      else if (buttonB == HIGH){
        input = 2;
        vTaskDelay(pdMS_TO_TICKS(buttonDelay));
      }
      else {input = 0;}
    break;
    case false:
      if (buttonA == LOW){
        input = 1;
        vTaskDelay(pdMS_TO_TICKS(buttonDelay));
      }
      else if (buttonB == LOW){
        input = 2;
        vTaskDelay(pdMS_TO_TICKS(buttonDelay));
      }
      else {input = 0;}
    break;
  }
  return input;
}
// Sjekker og kobler til wifi. Er wifi koblet til på nytt eller for første gang kobles mqtt opp.
void EspUtilities::connect_MQTT(){
  //Wifi statuser som wifi.status() gir
  enum wifiStatuses{WL_IDLE_STATUS = 0, WL_NO_SSID_AVAIL = 1, WL_SCAN_COMPLETED = 2, WL_CONNECTED =	3, WL_CONNECT_FAILED = 4, WL_CONNECTION_LOST = 5, WL_DISCONNECTED = 6, WL_NO_SHIELD = 255};
  bool wifiTimeout = false;
  int wifiAttemptCount = 0;
  int wifiTimeoutOnAttemptX = 10;
  bool connectMQTT = false;

  // Connect to the WiFi
  //Sjekker wifistatus
  int statusWifi = WiFi.status();   
  //er wifi frakoblet prover vi å koble til wifiTimeoutOnAttemptX antall ganger
  while ( statusWifi != WL_CONNECTED && !wifiTimeout && !masterBreak) {   
    //kobler til wifi             
    WiFi.begin(ssid, wifi_password);
    Serial.print("Attempting to connect wifi, status: ");
    Serial.println(WiFi.status());
    Serial.println(ssid);
    // venter ett sekund før status sjekkes 
    vTaskDelay(pdMS_TO_TICKS(1000));
    //Sjekker status etter tilkoblingsforsøk                         
    statusWifi = WiFi.status();
    //Wifi tilkoblet variabel settes sann, men så lenge wifi ikke er tilkoblet vil while løkken ikke bli brutt.
    connectMQTT = true;                   
    //inkrementerer tellevariabel    
    wifiAttemptCount = wifiAttemptCount + 1;
    //Dersom antal tilkoblingsforsøk overskrider grenseverdi brytes while løkke med variabel wifiTimeout
    //Wifi tilkoblet variabel blir satt til usann.
    if(wifiAttemptCount > wifiTimeoutOnAttemptX){
      wifiTimeout = true;
      connectMQTT = false;
    } 
  }

  //kobler til mqtt kun om wifi er blitt koblet til på nytt. Det er kun da connectMQTT har fårr mulighet til å bli sann.
  if(connectMQTT){                                          
    Serial.print("IP address: ");
    Serial.println(WiFi.localIP());

    // Connect to MQTT Broker
    // client.connect returnerer boolsk sann dersom tilkobling var suksessfull.
    if (client.connect(clientID, mqtt_username, mqtt_password)) {
      Serial.println("Connected to MQTT Broker!");
      //Angir hvilket signal det skal lyttes til
      client.subscribe("home/outgoing");
      //Anngir funksjon som skal kjøre dersom callbackflagg detektere.
      client.setCallback(callback);

      //for feilsøking
      bool r= client.subscribe("home/outgoing");
      Serial.println(r);
    }
    else {
      Serial.println("Connection to MQTT Broker failed...");
    }
    //mqtt skal kun kjøre ved ny wifitilkobling.
    connectMQTT = false;
  }
}
//Sender parameter til mqtt dersom enterknapp trykkes. Returnerer sann dersom det er forsøkt å sende melding
bool EspUtilities::roomBook (String booking_id, String room_id, String personCount, String user_id){ //definerer funksjon med strenger
  //noInput = 0, exit = 1, enter = X  
  enum exit_enterX {noInputX, exitX, select};                
  //henter knappeinput
  int selectSend = EspUtilities::EscSel();
  //variabler
  int result = 0;
  //variabel settes til usann dersom sending var suksessfull
  bool fail = true;
  
  //Dersom enterknapp trykkes starter sendeprosedyren
  if(selectSend == select){
    slides3.lcdClear();       //skjermklarering
    slides3.sending();       //skjermmelding
    breakoutOfmqttMessage = false;
    //konkatinerer en strenge med data for sending via mqtt. Tjeneren skiller strengen på "x" for å separere dataen den får tilsendt
    String bookingData = booking_id + "x" + user_id + "x" + room_id + "x" + personCount; //slår sammen strenger for overføring
    //client.publish returnerer boolsk sann dersom data ble sendt.
    if (client.publish(roomCheck_topic, String(bookingData).c_str())) { //publiserer data til "emnet"
      Serial.println("roombooking sent!"); //Bekreftelse på at rom-bookingen er sendt
      Serial.println(String(bookingData).c_str()); //Printer hva som ble sendt
      //Sletter linje 1 på skjermen i påvente av nytt skjermtekst
      slides3.blankLine1();
      long currentMillis = millis();
      long previousMillis = currentMillis;
      //lytter etter callback med skjermbildet "venter" intill tiden har gått ut eller utbrytervariabel blir sann
      while(currentMillis - previousMillis < maxResponseTime && !breakoutOfmqttMessage && !masterBreak){
        currentMillis = millis();
        slides3.waiting();
        //lytter etter callback
        //Dersom callbackflagg detekteres kjøres callbackfunksjonen (programlinje 24 til 52)
        //callbackfunksjonen bryter while-løkka.
        client.loop();         
      }
      //variabel settes til usann nå som sendinga var suksessfull
      fail = false;
      
    }
    else {
      //sending feiler noen ganger på første forsøk.
      //forsøker derfor å koble til mqtt på nytt før ny publisering/sending.
      Serial.println("Failed to send. Reconnecting to MQTT Broker and trying again");
      //Kobler til mqtt på nytt
      client.connect(clientID, mqtt_username, mqtt_password);
      vTaskDelay(pdMS_TO_TICKS(10)); // Delay slik at client.publish ikke krasjer med client.connect
      //setter sammen strenger for overføring
      String bookingData = booking_id + "x" + user_id + "x" + room_id + "x" + personCount; 
      //sener på nytt
      if(client.publish(roomCheck_topic, String(bookingData).c_str())){  //Forsøker å publisere data igjen
        slides3.blankLine1();      
        long currentMillis = millis();
        long previousMillis = currentMillis;
        while(currentMillis - previousMillis < maxResponseTime && !breakoutOfmqttMessage && !masterBreak){
          currentMillis = millis();
          slides3.waiting();
          client.loop();
        }
      //variabel settes til usann nå som sendinga var suksessfull
        fail = false;
      }
    }
    //Dersom meldingen feilet blir feilmelding vist på skjerm
    if(fail){
      slides3.lcdClear();       //skjermklarering
      slides3.mqttFailed();
      vTaskDelay(pdMS_TO_TICKS(responseMessageTime));
    }
    slides3.lcdClear();       //skjermklarering
    
    return true;
  }
  return false;    
}

//Et skall rundt funksjonen roomBook. Kan inkrementere variabel levelXInc for å anngi parameter som for eksempel antall personer.
void EspUtilities::booking(int bookingId, int roomId, int maxPeople, int minimumQuantity, const long messageTime){
  //noInput = 0, exit = 1, enter = X
  enum exit_enterX {noInputX, exitX, select};
  //variabel for input fra exit og enter knappene                      
  int inputEscSelX = 0;
  //Setter variabelen som inkrementeres til en minimumsverdi                                            
  int levelXInc = minimumQuantity;                                 
  //variabel brukes til å sjekke om nivå er endret  
  int tempX = 0;    
  //Sending er forsøkt variabel                                                  
  bool sendit = false;

  //knappeinput
  inputEscSelX = EspUtilities::EscSel();
  if(inputEscSelX == select){
    //nulstiller knappeinput 
    inputEscSelX = noInputX; 
    //Klarerer skjerm etter å ha gått inn til nytt undernivå
    slides3.lcdClear();                
    //er i while løkke til exit knapp trykkes, sending er forsøkt eller hoverutbryter er sann
    while(inputEscSelX != exitX && !sendit && !masterBreak){                                    
      //inkrementerer variabelen levelXInc. +1 fordi funksjonen levelselect går egentlig fra 0 til level==maxlevel.                  
      levelXInc = EspUtilities::levelSelect(levelXInc, maxPeople + 1, minimumQuantity);         

      //sletter en del av skjermbildet om variabel er inkrementert
      if (levelXInc != tempX){                          
        tempX = levelXInc;
        slides3.blankLine2();
      }         
      //skjermbilde som endres med inkrementeringsvariabelen
      //**Antall: "levelXInc"**             
      slides3.incrementAndSend(levelXInc, maxPeople);

      //Sender inkrementert variabel til tjener
      //sendit bryter ut fra whileloop om det er forsjøkt å sende til mqtt
      sendit = EspUtilities::roomBook ((String)bookingId, (String)roomId, (String)levelXInc);  

      //Sjekker input fra enter og exit knappene
      inputEscSelX = EspUtilities::EscSel();     
    }
    //bryter ut av undernivået om exit knapp trykkes
    if(inputEscSelX == exitX){
      inputEscSelX = noInputX; 
      slides3.lcdClear();
    }
    //Sletter skjermbildet dersom booking avsluttes         
    slides3.lcdClear();
  }
}
//True om wifi er ok
bool EspUtilities::checkWifi(){
  enum wifiStatuses{WL_IDLE_STATUS = 0, WL_NO_SSID_AVAIL = 1, WL_SCAN_COMPLETED = 2, WL_CONNECTED =	3, WL_CONNECT_FAILED = 4, WL_CONNECTION_LOST = 5, WL_DISCONNECTED = 6, WL_NO_SHIELD = 255};
  bool status = false;
  int readWifi = WiFi.status();
  if(readWifi != WL_CONNECTED){
    status = false;
  }
  else{status = true;}
  return status;
}
//For debugging. 
void EspUtilities::print_wakeup_reason(){
  esp_sleep_wakeup_cause_t wakeup_reason;
  wakeup_reason = esp_sleep_get_wakeup_cause();
  switch(wakeup_reason)
  {
    case ESP_SLEEP_WAKEUP_EXT0 : Serial.println("Wakeup caused by external signal using RTC_IO"); break;
    case ESP_SLEEP_WAKEUP_EXT1 : Serial.println("Wakeup caused by external signal using RTC_CNTL"); break;
    case ESP_SLEEP_WAKEUP_TIMER : Serial.println("Wakeup caused by timer"); break;
    case ESP_SLEEP_WAKEUP_TOUCHPAD : Serial.println("Wakeup caused by touchpad"); break;
    case ESP_SLEEP_WAKEUP_ULP : Serial.println("Wakeup caused by ULP program"); break;
    default : Serial.printf("Wakeup was not caused by deep sleep: %d\n",wakeup_reason); break;
  }
}







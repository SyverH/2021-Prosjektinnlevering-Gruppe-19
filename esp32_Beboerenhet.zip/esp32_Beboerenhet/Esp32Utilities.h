//***Funksjoner til bruk i hovedprogram***

//Sjekker om headerfila er kjørt. Alternativt #pragma once
#ifndef Esp32_Utilities  
//Er den ikke kjørt blir fila kjørt, hvis ikke hopper koden til nederste #endif 
#define Esp32_Utilities   

//Sjekker hvilken arduinoversjon som brukes og legger til riktig arduino headaer.
#if (ARDUINO >=100)    
  #include "Arduino.h"
#else
  #include "WProgram.h"
#endif

//Definerer variabelnavn som er definert fra før i . ino fila.
//Gjøres for å hente instillingsparameter
extern int userId;

//WiFi innstillinger
extern const char* ssid;          // SSID til nettverket
extern const char* wifi_password; // Nettverkspassord

// MQTT innstillinger
extern const char* mqtt_server;  // IP of the MQTT broker
extern const char* roomCheck_topic;
extern const char* mqtt_username; // MQTT username
extern const char* mqtt_password; // MQTT password
extern const char* clientID; // MQTT client ID
extern const char* mqtt_Recieve_topic;

//Knappekonfigurasjon
extern const uint8_t pinButtonBack;       //bryterinputpin fra .ino fila
extern const uint8_t pinButtonEnter;      //bryterinputpin fra .ino fila
extern const uint8_t pinButtonLeft;       //bryterinputpin fra .ino fila
extern const uint8_t pinButtonRight;      //bryterinputpin fra .ino fila
extern const bool pullUp_or_Down;         //brytertype fra .ino fila
extern const int buttonDelay;             //knappedelay fra .ino fila

//Konstanter for tidsparameter
extern const long maxResponseTime;
extern const long responseMessageTime;
extern bool masterBreak;

//Oppretter klasse hvor funksjoner deklareres.
//Kan dermed kalle på klassen for å bruke funksjonene når .h fila er inkludert
class EspUtilities  {
  //Funksjoner man kan kalle på når man kaller på klassen ligger under public
  public:
    //standardparameter for funksjoner defineres her så slipper man å skrive det når funksjonen skal brukes

    // Constructor for klassen
    EspUtilities(bool displayMsg=false);

    //seriell kommunikasjon
    void begin(int baudRate);                                             
    //Inkrementerer 1 opp eller ned fra variabel level. Returnerer int mellom 0 og variabel levels. Input fra to brytere. Pulldown eller pullup angis til slutt
    int levelSelect(int level, const int levels, const int minLevel = 0, const uint8_t pinButtonA = pinButtonLeft, const uint8_t pinButtonB = pinButtonRight , const bool pulldown = pullUp_or_Down, const int buttonDelay = buttonDelay);
    //Mapper to knapper til int 1 og int 2. int 0 ved ingen knapp trykket. Pulldownbrytere -> pulldown=true Pullupbrytere -> pullup=false.
    int EscSel(const int pinButtonA = pinButtonBack, const int pinButtonB = pinButtonEnter, const bool pulldown = pullUp_or_Down, const int buttonDelay = buttonDelay);
    //Samme som EscSel. Det var oversiklig å ha to funksjoner med navn som tilsvarer knappene (not)
    int buttonsMinusPlus(const int pinButtonA = pinButtonLeft, const int pinButtonB = pinButtonRight, const bool pulldown = pullUp_or_Down, const int buttonDelay = buttonDelay);
    // Kobler til wifi og deretter mqtt
    void connect_MQTT();
    //Sender booking til mqtt. Tar inn parameter som mqtt server forstår altså streng.
    bool roomBook(String booking_id, String room_id, String personCount, String user_id = (String) userId);
    //Et skall rundt roomBook. Lar deg velge hvor mange du vil bestille. Bestillinga legges inn i roobBook og sendes til mqtt server
    void booking(int bookingId, int roomId, int maxPeople = 5, int minimumQuantity = 1, const long messageTime = responseMessageTime);
    //returnerer true om wifi er ok. false 
    bool checkWifi();
    //For debugging. 
    void print_wakeup_reason();

    
  //Funksjoner man ikke kan kalle på når man kaller på klassen ligger under private. Disse kan kun brukes internt i klassen
  private:
    bool _msg;
    //void callback(const char* mqtt_Recieve_topic, uint8_t* payload, unsigned int length);
};
#endif
